/***************************************************************************\
 * mmsound.h
 *
 * (c) 1994 by Nicole Greiber
 * Set tabs to 3 to get a readable source.
\***************************************************************************/
#ifdef INITIALIZE
#undef PUBLIC
#define PUBLIC
#endif
PUBLIC VOID PlaySound( const ULONG sound );
